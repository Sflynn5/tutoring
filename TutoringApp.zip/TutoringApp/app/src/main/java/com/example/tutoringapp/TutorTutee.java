package com.example.tutoringapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class TutorTutee extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tutor_tutee);

        final Button tutor = findViewById(R.id.button);
        tutor.setOnClickListener(new View.OnClickListener(){
            public void onClick(View t){
                setContentView(R.layout.activity_subject_for__tutors);
            }
        });

        final Button student = findViewById(R.id.button2);
        student.setOnClickListener(new View.OnClickListener(){
            public void onClick(View s){
                setContentView(R.layout.activity_subject_for__students);
            }
        });
    }
}
