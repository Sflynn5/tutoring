package com.example.tutoringapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Subject_for_Tutors extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subject_for__tutors);
    }
}
